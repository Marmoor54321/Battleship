﻿
using var game = new Battleship.Game1();
game.Run();
